﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Task3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AnimatedButton_Loaded(object sender, RoutedEventArgs e)
        {
            DoubleAnimation fontSizeAnimation = new DoubleAnimation
            {
                From = 14,
                To = 28,
                Duration = TimeSpan.FromSeconds(1),
                AutoReverse = true,
                RepeatBehavior = new RepeatBehavior(2)
            };

            DoubleAnimation widthAnimation = new DoubleAnimation
            {
                From = AnimatedButton.ActualWidth,
                To = AnimatedButton.ActualWidth * 2,
                Duration = TimeSpan.FromSeconds(1),
                AutoReverse = true,
                RepeatBehavior = new RepeatBehavior(2)
            };

            DoubleAnimation heightAnimation = new DoubleAnimation
            {
                From = AnimatedButton.ActualHeight,
                To = AnimatedButton.ActualHeight * 2,
                Duration = TimeSpan.FromSeconds(1),
                AutoReverse = true,
                RepeatBehavior = new RepeatBehavior(2)
            };

            AnimatedButton.BeginAnimation(Button.FontSizeProperty, fontSizeAnimation);
            AnimatedButton.BeginAnimation(Button.WidthProperty, widthAnimation);
            AnimatedButton.BeginAnimation(Button.HeightProperty, heightAnimation);
        }
    }
}